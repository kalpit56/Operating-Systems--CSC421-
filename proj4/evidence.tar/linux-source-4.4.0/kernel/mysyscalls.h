
/*
 * mysyscalls.h
 *
 * this is the header file that is included in both
 * the user files that use the new system calls and 
 * the kernel files that implement the new system calls
 *
 * author: Kalpit Mody
 * date: 09/24/2020
 *
 */


#define MY_SYSLOG 377

